"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RegisterComponent = void 0;
var core_1 = require("@angular/core");
var user_model_1 = require("src/app/models/user.model");
var RegisterComponent = /** @class */ (function () {
    function RegisterComponent(userService, router, route) {
        this.userService = userService;
        this.router = router;
        this.route = route;
        this.userInfo = null;
        this.message = ' ';
        this.success = true;
        this.userInfo = new user_model_1.User('', '', '', '', '');
        if (this.route.snapshot.paramMap.get('msg')) {
            this.message = this.route.snapshot.paramMap.get('msg');
        }
    }
    RegisterComponent.prototype.ngOnInit = function () {
    };
    RegisterComponent.prototype.CreateUser = function () {
        var _this = this;
        if (this.userInfo !== null) {
            this.userService.CreateUser(this.userInfo).subscribe(function (response) {
                _this.success = true;
                _this.router.navigate(['/login', { msg: 'Your account has been created successfully. Please log in here.' }]);
            }, function (error) {
                _this.success = false;
                _this.message = error.error.message;
            });
        }
    };
    RegisterComponent = __decorate([
        core_1.Component({
            selector: 'app-register',
            templateUrl: './register.component.html',
            styleUrls: ['./register.component.css']
        })
    ], RegisterComponent);
    return RegisterComponent;
}());
exports.RegisterComponent = RegisterComponent;
