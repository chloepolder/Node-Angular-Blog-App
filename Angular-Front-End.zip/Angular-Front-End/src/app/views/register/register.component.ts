import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user.model';
import { UserserviceService } from 'src/app/services/userservice.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  userInfo:User|null=null;
  message:string=' ';
  success:boolean= true;
  constructor(private userService:UserserviceService, private router:Router, private route:ActivatedRoute){
    this.userInfo= new User('','','','','');
    if(this.route.snapshot.paramMap.get('msg'))
    {
      this.message = this.route.snapshot.paramMap.get('msg') as string;
    }
   }

  ngOnInit(): void {
  }

  CreateUser(){
    if(this.userInfo !== null){
      this.userService.CreateUser(this.userInfo).subscribe((response)=>{
        this.success = true;
        this.router.navigate(['/login', {msg:'Your account has been created successfully. Please log in here.'}]);
      },(error)=>{
        this.success = false;
        this.message = error.error.message;
      })
    }
    
  }
}
