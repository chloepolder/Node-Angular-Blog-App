import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Post } from 'src/app/models/post.model';
import { Token } from 'src/app/models/token.model';
import { PostService } from 'src/app/services/post.service';
import { UserserviceService } from 'src/app/services/userservice.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  postAry:Post[] = [];
  userIsLoggedIn = false;
  currentUser: Token|null=null;
  message:string=' ';
  success:boolean= true;

  constructor(private postService:PostService, private userService: UserserviceService, private router: Router, private route:ActivatedRoute) {
    if(this.route.snapshot.paramMap.get('msg'))
    {
      this.message = this.route.snapshot.paramMap.get('msg') as string;
    }
    this.postService.GetPosts().subscribe((postArray) =>{
      this.postAry = postArray;
    },(error)=>{
      console.log(error);
    }); 
    let userLoggedIn = this.userService.GetLoggedInUser();
    if (userLoggedIn != null){
      this.userIsLoggedIn = true;
      this.currentUser = userLoggedIn;
    }
    this.userService.UserStateChanged.subscribe((userLoggedIn)=>{
      this.userIsLoggedIn = userLoggedIn;
    });
  }
  
  
  ngOnInit(): void {
  }

}
