"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateComponent = void 0;
var http_1 = require("@angular/common/http");
var core_1 = require("@angular/core");
var post_model_1 = require("src/app/models/post.model");
var CreateComponent = /** @class */ (function () {
    function CreateComponent(postService, userService, router, route) {
        this.postService = postService;
        this.userService = userService;
        this.router = router;
        this.route = route;
        this.postInfo = null;
        this.message = ' ';
        this.success = true;
        this.currentUser = null;
        this.postInfo = new post_model_1.Post(0, '', '', '', '', '', '');
        if (this.route.snapshot.paramMap.get('msg')) {
            this.message = this.route.snapshot.paramMap.get('msg');
        }
        var userLoggedIn = this.userService.GetLoggedInUser();
        if (userLoggedIn != null) {
            this.currentUser = userLoggedIn;
        }
    }
    CreateComponent.prototype.ngOnInit = function () {
    };
    CreateComponent.prototype.CreatePost = function () {
        var _this = this;
        if (this.postInfo !== null) {
            var tokenString = localStorage.getItem('token');
            if (tokenString !== null) {
                var tokenObj = JSON.parse(tokenString);
                var headers = new http_1.HttpHeaders({ 'token': tokenObj.token });
                this.postService.CreatePost(this.postInfo, headers).subscribe(function (response) {
                    _this.success = true;
                    _this.router.navigate(['/home', { msg: 'Your post was created.' }]);
                }, function (error) {
                    _this.success = false;
                    _this.message = error.error.message;
                });
            }
        }
    };
    CreateComponent = __decorate([
        core_1.Component({
            selector: 'app-create',
            templateUrl: './create.component.html',
            styleUrls: ['./create.component.css']
        })
    ], CreateComponent);
    return CreateComponent;
}());
exports.CreateComponent = CreateComponent;
