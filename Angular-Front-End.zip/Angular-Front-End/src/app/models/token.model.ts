export class Token {
    firstName:string;
    userId:string;
    exp:number;
    iat:number;

    constructor (firstName:string, userId:string, exp:number, iat:number){
        this.firstName = firstName;
        this.userId = userId;
        this.exp = exp;
        this.iat = iat;
    }
}
