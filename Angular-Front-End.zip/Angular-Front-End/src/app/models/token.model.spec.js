"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var token_model_1 = require("./token.model");
describe('Token', function () {
    it('should create an instance', function () {
        expect(new token_model_1.Token()).toBeTruthy();
    });
});
