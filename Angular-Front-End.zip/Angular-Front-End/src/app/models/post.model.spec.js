"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var post_model_1 = require("./post.model");
describe('Post', function () {
    it('should create an instance', function () {
        expect(new post_model_1.Post()).toBeTruthy();
    });
});
