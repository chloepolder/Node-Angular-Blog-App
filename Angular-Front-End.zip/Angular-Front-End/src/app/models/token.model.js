"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Token = void 0;
var Token = /** @class */ (function () {
    function Token(firstName, userId, exp, iat) {
        this.firstName = firstName;
        this.userId = userId;
        this.exp = exp;
        this.iat = iat;
    }
    return Token;
}());
exports.Token = Token;
