"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var user_model_1 = require("./user.model");
describe('User', function () {
    it('should create an instance', function () {
        expect(new user_model_1.User()).toBeTruthy();
    });
});
