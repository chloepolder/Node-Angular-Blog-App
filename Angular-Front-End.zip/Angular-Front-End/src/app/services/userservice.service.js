"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserserviceService = void 0;
var core_1 = require("@angular/core");
var jwt_decode_1 = __importDefault(require("jwt-decode"));
var environment_1 = require("src/environments/environment");
var UserserviceService = /** @class */ (function () {
    function UserserviceService(httpC) {
        this.httpC = httpC;
        this.userIsLoggedIn = false;
        this.UserStateChanged = new core_1.EventEmitter();
    }
    UserserviceService.prototype.Login = function (userId, password) {
        return this.httpC.get(environment_1.environment.BASE_URL + '/Users/' + userId + '/' + password);
    };
    UserserviceService.prototype.SetUserLoggedIn = function (userToken) {
        localStorage.setItem('token', JSON.stringify(userToken));
        this.UserStateChanged.emit(true);
    };
    UserserviceService.prototype.SetUserLoggedOut = function () {
        localStorage.removeItem('token');
        this.UserStateChanged.emit(true);
    };
    UserserviceService.prototype.CreateUser = function (userInfo) {
        return this.httpC.post(environment_1.environment.BASE_URL + '/Users', userInfo);
    };
    UserserviceService.prototype.GetLoggedInUser = function () {
        var tokenString = localStorage.getItem('token');
        if (tokenString !== null) {
            var tokenObj = JSON.parse(tokenString);
            var tokenInfo = jwt_decode_1.default(tokenObj.token);
            return tokenInfo;
        }
        else {
            return null;
        }
    };
    __decorate([
        core_1.Output()
    ], UserserviceService.prototype, "UserStateChanged", void 0);
    UserserviceService = __decorate([
        core_1.Injectable({
            providedIn: 'root'
        })
    ], UserserviceService);
    return UserserviceService;
}());
exports.UserserviceService = UserserviceService;
