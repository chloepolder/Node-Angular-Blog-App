"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var testing_1 = require("@angular/core/testing");
var authguard_service_1 = require("./authguard.service");
describe('AuthguardService', function () {
    var service;
    beforeEach(function () {
        testing_1.TestBed.configureTestingModule({});
        service = testing_1.TestBed.inject(authguard_service_1.AuthguardService);
    });
    it('should be created', function () {
        expect(service).toBeTruthy();
    });
});
