"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var testing_1 = require("@angular/core/testing");
var userservice_service_1 = require("./userservice.service");
describe('UserserviceService', function () {
    var service;
    beforeEach(function () {
        testing_1.TestBed.configureTestingModule({});
        service = testing_1.TestBed.inject(userservice_service_1.UserserviceService);
    });
    it('should be created', function () {
        expect(service).toBeTruthy();
    });
});
