"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostinstanceComponent = void 0;
var core_1 = require("@angular/core");
var PostinstanceComponent = /** @class */ (function () {
    function PostinstanceComponent(userService, router) {
        var _this = this;
        this.userService = userService;
        this.router = router;
        this.userIsLoggedIn = false;
        this.currentUser = null;
        var userLoggedIn = this.userService.GetLoggedInUser();
        if (userLoggedIn != null) {
            this.userIsLoggedIn = true;
            this.currentUser = userLoggedIn;
        }
        this.userService.UserStateChanged.subscribe(function (userLoggedIn) {
            _this.userIsLoggedIn = userLoggedIn;
        });
    }
    PostinstanceComponent.prototype.ngOnInit = function () {
    };
    __decorate([
        core_1.Input()
    ], PostinstanceComponent.prototype, "postInstance", void 0);
    PostinstanceComponent = __decorate([
        core_1.Component({
            selector: 'app-postinstance',
            templateUrl: './postinstance.component.html',
            styleUrls: ['./postinstance.component.css']
        })
    ], PostinstanceComponent);
    return PostinstanceComponent;
}());
exports.PostinstanceComponent = PostinstanceComponent;
