import { Component, OnInit } from '@angular/core';
import {faSignInAlt} from '@fortawesome/free-solid-svg-icons';
import {faSignOutAlt} from '@fortawesome/free-solid-svg-icons';
import {faUserPlus} from '@fortawesome/free-solid-svg-icons';
import { UserserviceService } from 'src/app/services/userservice.service';
import { Router } from '@angular/router';
import { Token } from 'src/app/models/token.model';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  signInIcon = faSignInAlt;
  signOutIcon = faSignOutAlt;
  registerIcon = faUserPlus;
  userIsLoggedIn = false;
  currentUser: Token|null=null;

  constructor(private userService: UserserviceService, private router: Router) { 
    let userLoggedIn = this.userService.GetLoggedInUser();
    if (userLoggedIn != null){
      this.userIsLoggedIn = true;
      this.currentUser = userLoggedIn;
    }
    this.userService.UserStateChanged.subscribe((userLoggedIn)=>{
      this.userIsLoggedIn = userLoggedIn;
    });
  }

  ngOnInit(): void {
  }
  
  LogoutUser(){
    this.userService.SetUserLoggedOut();
    this.userIsLoggedIn = false;
    this.router.navigate(['/login']);
  }
}
